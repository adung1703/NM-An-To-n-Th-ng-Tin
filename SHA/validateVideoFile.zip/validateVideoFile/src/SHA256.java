import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class SHA256 {
    public static void main(String[] args) {
        String filePath = "E:\\NM An Toàn Thông Tin\\SHA\\validateVideoFile\\src\\birthday.mp4"; // Đường dẫn tới tập tin cần xử lý
        int blockSize = 1024; // Kích thước 1 block

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            // Đọc dữ liệu từ tập tin
            Path path = Paths.get(filePath);
            byte[] data = Files.readAllBytes(path);

            int numBlocks = (data.length + blockSize - 1) / blockSize; // Số block trong file
            byte[] hash = null; // Kết quả băm

            // Xét từng block
            for (int i = numBlocks - 1; i >= 0; i--) {
                int begin = i * blockSize; // Vị trí bắt đầu của block
                int end = Math.min(begin + blockSize, data.length); // Vị trí kết thúc

                byte[] block = Arrays.copyOfRange(data, begin, end); // Chép dữ liệu sang block

                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

                // Ghép block với hash (nếu có)
                outputStream.write(block);
                if (hash != null) {
                    outputStream.write(hash);
                }

                byte[] blockWithHash = outputStream.toByteArray();
                // Băm
                hash = digest.digest(blockWithHash);
            }

            // In ra màn hình kết quả
            StringBuffer hexString = new StringBuffer();
            for (int i = 0; i < hash.length; i++) {
                String hex = Integer.toHexString(0xff & hash[i]);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            System.out.println("SHA-256 hash của file là:");
            System.out.println(hexString.toString());
        } catch (NoSuchAlgorithmException | IOException e) {
            e.printStackTrace();
        }
    }
}
